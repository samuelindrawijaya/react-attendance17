"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Plus, Edit, Trash2, Eye, Search } from "lucide-react"
import type { Employee, Role } from "@/types"

const mockRoles: Role[] = [
  { id: "1", name: "Admin", description: "Full access", permissions: [], created_at: "", updated_at: "" },
  { id: "2", name: "Employee", description: "Basic access", permissions: [], created_at: "", updated_at: "" },
  { id: "3", name: "HR", description: "HR access", permissions: [], created_at: "", updated_at: "" },
]

const mockEmployees: Employee[] = [
  {
    id: "1",
    user_id: "1",
    full_name: "John Doe",
    nik: "EMP001",
    department: "Engineering",
    position: "Frontend Developer",
    phone: "+1234567890",
    address: "123 Main St, City",
    hire_date: "2023-01-15T00:00:00Z",
    status: "active",
    created_at: "2023-01-15T00:00:00Z",
    updated_at: "2023-01-15T00:00:00Z",
    user: {
      id: "1",
      email: "john@company.com",
      name: "John Doe",
      role_id: "2",
      is_active: true,
      created_at: "2023-01-15T00:00:00Z",
      updated_at: "2023-01-15T00:00:00Z",
    },
  },
  {
    id: "2",
    user_id: "2",
    full_name: "Jane Smith",
    nik: "EMP002",
    department: "HR",
    position: "HR Manager",
    phone: "+1234567891",
    address: "456 Oak Ave, City",
    hire_date: "2023-02-01T00:00:00Z",
    status: "active",
    created_at: "2023-02-01T00:00:00Z",
    updated_at: "2023-02-01T00:00:00Z",
    user: {
      id: "2",
      email: "jane@company.com",
      name: "Jane Smith",
      role_id: "1",
      is_active: true,
      created_at: "2023-02-01T00:00:00Z",
      updated_at: "2023-02-01T00:00:00Z",
    },
  },
]

interface EmployeeManagementProps {
  onViewProfile: (employee: Employee) => void
}

export default function EmployeeManagement({ onViewProfile }: EmployeeManagementProps) {
  const [employees, setEmployees] = useState<Employee[]>(mockEmployees)
  const [searchTerm, setSearchTerm] = useState("")
  const [showForm, setShowForm] = useState(false)
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [formData, setFormData] = useState({
    full_name: "",
    nik: "",
    email: "",
    department: "",
    position: "",
    phone: "",
    address: "",
    hire_date: "",
    role_id: "2",
    password: "",
  })

  const filteredEmployees = employees.filter(
    (emp) =>
      emp.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.nik.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.position.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingEmployee) {
      // Update existing employee
      setEmployees(
        employees.map((emp) =>
          emp.id === editingEmployee.id
            ? {
                ...emp,
                full_name: formData.full_name,
                nik: formData.nik,
                department: formData.department,
                position: formData.position,
                phone: formData.phone,
                address: formData.address,
                hire_date: formData.hire_date,
                updated_at: new Date().toISOString(),
                user: emp.user
                  ? {
                      ...emp.user,
                      email: formData.email,
                      name: formData.full_name,
                      role_id: formData.role_id,
                      updated_at: new Date().toISOString(),
                    }
                  : undefined,
              }
            : emp,
        ),
      )
    } else {
      // Create new employee
      const newEmployee: Employee = {
        id: Date.now().toString(),
        user_id: (Date.now() + 1).toString(),
        full_name: formData.full_name,
        nik: formData.nik,
        department: formData.department,
        position: formData.position,
        phone: formData.phone,
        address: formData.address,
        hire_date: formData.hire_date,
        status: "active",
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        user: {
          id: (Date.now() + 1).toString(),
          email: formData.email,
          name: formData.full_name,
          role_id: formData.role_id,
          is_active: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      }
      setEmployees([...employees, newEmployee])
    }

    resetForm()
  }

  const resetForm = () => {
    setFormData({
      full_name: "",
      nik: "",
      email: "",
      department: "",
      position: "",
      phone: "",
      address: "",
      hire_date: "",
      role_id: "2",
      password: "",
    })
    setShowForm(false)
    setEditingEmployee(null)
  }

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee)
    setFormData({
      full_name: employee.full_name,
      nik: employee.nik,
      email: employee.user?.email || "",
      department: employee.department,
      position: employee.position,
      phone: employee.phone,
      address: employee.address,
      hire_date: employee.hire_date.split("T")[0],
      role_id: employee.user?.role_id || "2",
      password: "",
    })
    setShowForm(true)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this employee?")) {
      setEmployees(employees.filter((emp) => emp.id !== id))
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Employee Management</h2>
          <p className="text-gray-600">Manage employee data and accounts</p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Employee
        </Button>
      </div>

      {/* Search */}
      <div className="flex items-center space-x-2">
        <Search className="h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search employees..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
      </div>

      {/* Employee Form */}
      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>{editingEmployee ? "Edit Employee" : "Add New Employee"}</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="full_name">Full Name</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData((prev) => ({ ...prev, full_name: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="nik">Employee ID (NIK)</Label>
                  <Input
                    id="nik"
                    value={formData.nik}
                    onChange={(e) => setFormData((prev) => ({ ...prev, nik: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="phone">Phone</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={formData.department}
                    onChange={(e) => setFormData((prev) => ({ ...prev, department: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="position">Position</Label>
                  <Input
                    id="position"
                    value={formData.position}
                    onChange={(e) => setFormData((prev) => ({ ...prev, position: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="hire_date">Hire Date</Label>
                  <Input
                    id="hire_date"
                    type="date"
                    value={formData.hire_date}
                    onChange={(e) => setFormData((prev) => ({ ...prev, hire_date: e.target.value }))}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="role_id">Role</Label>
                  <select
                    id="role_id"
                    value={formData.role_id}
                    onChange={(e) => setFormData((prev) => ({ ...prev, role_id: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md"
                    required
                  >
                    {mockRoles.map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData((prev) => ({ ...prev, address: e.target.value }))}
                  required
                />
              </div>

              {!editingEmployee && (
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData((prev) => ({ ...prev, password: e.target.value }))}
                    required
                  />
                </div>
              )}

              <div className="flex space-x-2">
                <Button type="submit">{editingEmployee ? "Update Employee" : "Create Employee"}</Button>
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Employee Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Employee</th>
                  <th className="text-left p-4 font-medium">NIK</th>
                  <th className="text-left p-4 font-medium">Department</th>
                  <th className="text-left p-4 font-medium">Position</th>
                  <th className="text-left p-4 font-medium">Status</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredEmployees.map((employee) => (
                  <tr key={employee.id} className="border-b hover:bg-gray-50">
                    <td className="p-4">
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                          {/* User icon here */}
                        </div>
                        <div>
                          <p className="font-medium">{employee.full_name}</p>
                          <p className="text-sm text-gray-600">{employee.user?.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 font-mono text-sm">{employee.nik}</td>
                    <td className="p-4">{employee.department}</td>
                    <td className="p-4">{employee.position}</td>
                    <td className="p-4">
                      <Badge variant={employee.status === "active" ? "default" : "secondary"}>{employee.status}</Badge>
                    </td>
                    <td className="p-4">
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" onClick={() => onViewProfile(employee)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleEdit(employee)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleDelete(employee.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
