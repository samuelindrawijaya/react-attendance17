"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, User, Mail, Phone, MapPin, Calendar, Building, Briefcase, Clock, TrendingUp } from "lucide-react"
import type { Employee, AttendanceRecord } from "@/types"

const mockAttendanceHistory: AttendanceRecord[] = [
  {
    id: "1",
    user_id: "1",
    employee_id: "1",
    date: "2024-01-15",
    check_in: "2024-01-15T09:00:00Z",
    check_out: "2024-01-15T17:30:00Z",
    type: "wfh",
    photo: "/placeholder.svg?height=100&width=100",
    notes: "Working from home today",
    created_at: "2024-01-15T09:00:00Z",
    updated_at: "2024-01-15T17:30:00Z",
  },
  {
    id: "2",
    user_id: "1",
    employee_id: "1",
    date: "2024-01-14",
    check_in: "2024-01-14T08:45:00Z",
    check_out: "2024-01-14T17:15:00Z",
    type: "onsite",
    photo: "/placeholder.svg?height=100&width=100",
    notes: "Regular office day",
    created_at: "2024-01-14T08:45:00Z",
    updated_at: "2024-01-14T17:15:00Z",
  },
  {
    id: "3",
    user_id: "1",
    employee_id: "1",
    date: "2024-01-13",
    check_in: "2024-01-13T09:15:00Z",
    check_out: "2024-01-13T18:00:00Z",
    type: "wfh",
    photo: "/placeholder.svg?height=100&width=100",
    notes: "Extended work session",
    created_at: "2024-01-13T09:15:00Z",
    updated_at: "2024-01-13T18:00:00Z",
  },
]

interface EmployeeProfileProps {
  employee: Employee
  onBack: () => void
}

export default function EmployeeProfile({ employee, onBack }: EmployeeProfileProps) {
  const [activeTab, setActiveTab] = useState<"profile" | "attendance">("profile")
  const [attendanceHistory] = useState<AttendanceRecord[]>(mockAttendanceHistory)

  const calculateWorkingHours = (checkIn: string, checkOut?: string) => {
    if (!checkOut) return 0
    const start = new Date(checkIn)
    const end = new Date(checkOut)
    return Math.round(((end.getTime() - start.getTime()) / (1000 * 60 * 60)) * 10) / 10
  }

  const totalWorkingHours = attendanceHistory.reduce(
    (acc, record) => acc + calculateWorkingHours(record.check_in, record.check_out),
    0,
  )

  const averageWorkingHours = totalWorkingHours / attendanceHistory.length

  const wfhCount = attendanceHistory.filter((r) => r.type === "wfh").length
  const onsiteCount = attendanceHistory.filter((r) => r.type === "onsite").length

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <Button variant="outline" size="sm" onClick={onBack}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Employee Profile</h2>
          <p className="text-gray-600">View employee details and attendance history</p>
        </div>
      </div>

      {/* Profile Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex items-start space-x-6">
            <div className="h-24 w-24 rounded-full bg-gray-200 flex items-center justify-center">
              {employee.photo ? (
                <img
                  src={employee.photo || "/placeholder.svg"}
                  alt={employee.full_name}
                  className="h-24 w-24 rounded-full object-cover"
                />
              ) : (
                <User className="h-12 w-12 text-gray-500" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold">{employee.full_name}</h3>
                  <p className="text-lg text-gray-600">{employee.position}</p>
                  <p className="text-sm text-gray-500">NIK: {employee.nik}</p>
                </div>
                <Badge variant={employee.status === "active" ? "default" : "secondary"} className="text-sm">
                  {employee.status}
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Navigation Tabs */}
      <div className="flex space-x-1">
        <Button variant={activeTab === "profile" ? "default" : "outline"} onClick={() => setActiveTab("profile")}>
          <User className="h-4 w-4 mr-2" />
          Profile Details
        </Button>
        <Button variant={activeTab === "attendance" ? "default" : "outline"} onClick={() => setActiveTab("attendance")}>
          <Calendar className="h-4 w-4 mr-2" />
          Attendance History
        </Button>
      </div>

      {/* Profile Details Tab */}
      {activeTab === "profile" && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <Mail className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Email</p>
                  <p className="font-medium">{employee.user?.email}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Phone</p>
                  <p className="font-medium">{employee.phone}</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <MapPin className="h-5 w-5 text-gray-400 mt-1" />
                <div>
                  <p className="text-sm text-gray-600">Address</p>
                  <p className="font-medium">{employee.address}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Employment Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-3">
                <Building className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Department</p>
                  <p className="font-medium">{employee.department}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Briefcase className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Position</p>
                  <p className="font-medium">{employee.position}</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Calendar className="h-5 w-5 text-gray-400" />
                <div>
                  <p className="text-sm text-gray-600">Hire Date</p>
                  <p className="font-medium">{new Date(employee.hire_date).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Attendance History Tab */}
      {activeTab === "attendance" && (
        <div className="space-y-6">
          {/* Attendance Statistics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold">{attendanceHistory.length}</div>
                <p className="text-sm text-gray-600">Total Days</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-green-600">{wfhCount}</div>
                <p className="text-sm text-gray-600">WFH Days</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-blue-600">{onsiteCount}</div>
                <p className="text-sm text-gray-600">Onsite Days</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4">
                <div className="text-2xl font-bold text-purple-600">{Math.round(averageWorkingHours * 10) / 10}h</div>
                <p className="text-sm text-gray-600">Avg. Hours/Day</p>
              </CardContent>
            </Card>
          </div>

          {/* Attendance Records */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Attendance Records</CardTitle>
              <CardDescription>Last {attendanceHistory.length} attendance records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {attendanceHistory.map((record) => (
                  <div key={record.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <div className="text-sm font-medium">
                          {new Date(record.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                        </div>
                        <div className="text-xs text-gray-500">
                          {new Date(record.date).toLocaleDateString("en-US", { weekday: "short" })}
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <Badge variant={record.type === "wfh" ? "default" : "secondary"}>
                            {record.type === "wfh" ? "WFH" : "Onsite"}
                          </Badge>
                          <span className="text-sm text-gray-600">
                            {calculateWorkingHours(record.check_in, record.check_out)}h worked
                          </span>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          {new Date(record.check_in).toLocaleTimeString()} -{" "}
                          {record.check_out ? new Date(record.check_out).toLocaleTimeString() : "Not checked out"}
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
