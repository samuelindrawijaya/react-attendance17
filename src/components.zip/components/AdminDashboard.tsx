"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useAuth } from "@/contexts/AuthContext"
import { Building2, LogOut, Users, Calendar, Shield, BarChart3 } from "lucide-react"
import type { Employee } from "@/types"
import RoleManagement from "./RoleManagement"
import EmployeeManagement from "./EmployeeManagement"
import AttendanceMonitoring from "./AttendanceMonitoring"
import EmployeeProfile from "./EmployeeProfile"

export default function AdminDashboard() {
  const { user, logout } = useAuth()
  const [activeTab, setActiveTab] = useState<"dashboard" | "roles" | "employees" | "attendance">("dashboard")
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)
  const [photoModal, setPhotoModal] = useState<string | null>(null)

  const handleViewProfile = (employee: Employee) => {
    setSelectedEmployee(employee)
  }

  const handleViewPhoto = (photo: string) => {
    setPhotoModal(photo)
  }

  if (selectedEmployee) {
    return <EmployeeProfile employee={selectedEmployee} onBack={() => setSelectedEmployee(null)} />
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Building2 className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-xl font-semibold">Admin Dashboard</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user?.name}</span>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto p-6">
        {/* Navigation Tabs */}
        <div className="flex space-x-1 mb-8">
          <Button variant={activeTab === "dashboard" ? "default" : "outline"} onClick={() => setActiveTab("dashboard")}>
            <BarChart3 className="h-4 w-4 mr-2" />
            Dashboard
          </Button>
          <Button variant={activeTab === "roles" ? "default" : "outline"} onClick={() => setActiveTab("roles")}>
            <Shield className="h-4 w-4 mr-2" />
            Role Management
          </Button>
          <Button variant={activeTab === "employees" ? "default" : "outline"} onClick={() => setActiveTab("employees")}>
            <Users className="h-4 w-4 mr-2" />
            Employee Management
          </Button>
          <Button
            variant={activeTab === "attendance" ? "default" : "outline"}
            onClick={() => setActiveTab("attendance")}
          >
            <Calendar className="h-4 w-4 mr-2" />
            Attendance Monitoring
          </Button>
        </div>

        {/* Dashboard Overview */}
        {activeTab === "dashboard" && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-blue-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Employees</p>
                      <p className="text-2xl font-bold text-gray-900">24</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Calendar className="h-8 w-8 text-green-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Present Today</p>
                      <p className="text-2xl font-bold text-gray-900">18</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Building2 className="h-8 w-8 text-purple-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Departments</p>
                      <p className="text-2xl font-bold text-gray-900">5</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Shield className="h-8 w-8 text-orange-600" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Active Roles</p>
                      <p className="text-2xl font-bold text-gray-900">3</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">Welcome to Admin Dashboard</h3>
              <p className="text-gray-600">Select a tab above to manage roles, employees, or monitor attendance.</p>
            </div>
          </div>
        )}

        {/* Role Management Tab */}
        {activeTab === "roles" && <RoleManagement />}

        {/* Employee Management Tab */}
        {activeTab === "employees" && <EmployeeManagement onViewProfile={handleViewProfile} />}

        {/* Attendance Monitoring Tab */}
        {activeTab === "attendance" && <AttendanceMonitoring onViewPhoto={handleViewPhoto} />}
      </div>

      {/* Photo Modal */}
      {photoModal && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          onClick={() => setPhotoModal(null)}
        >
          <div className="bg-white p-4 rounded-lg max-w-2xl max-h-[80vh] overflow-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold">Attendance Photo</h3>
              <Button variant="outline" size="sm" onClick={() => setPhotoModal(null)}>
                Close
              </Button>
            </div>
            <img src={photoModal || "/placeholder.svg"} alt="Attendance photo" className="w-full h-auto rounded" />
          </div>
        </div>
      )}
    </div>
  )
}
