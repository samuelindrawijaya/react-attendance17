"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Calendar, Filter, Eye, Download, MapPin, Clock } from "lucide-react"
import type { AttendanceRecord, AttendanceFilter, Employee } from "@/types"

const mockAttendance: AttendanceRecord[] = [
  {
    id: "1",
    user_id: "1",
    employee_id: "1",
    date: "2024-01-15",
    check_in: "2024-01-15T09:00:00Z",
    check_out: "2024-01-15T17:30:00Z",
    type: "wfh",
    photo: "/placeholder.svg?height=100&width=100",
    notes: "Working from home today",
    created_at: "2024-01-15T09:00:00Z",
    updated_at: "2024-01-15T17:30:00Z",
    employee: {
      id: "1",
      user_id: "1",
      full_name: "John Doe",
      nik: "EMP001",
      department: "Engineering",
      position: "Frontend Developer",
      phone: "+1234567890",
      address: "123 Main St",
      hire_date: "2023-01-15T00:00:00Z",
      status: "active",
      created_at: "2023-01-15T00:00:00Z",
      updated_at: "2023-01-15T00:00:00Z",
    },
  },
  {
    id: "2",
    user_id: "2",
    employee_id: "2",
    date: "2024-01-15",
    check_in: "2024-01-15T08:45:00Z",
    check_out: "2024-01-15T17:15:00Z",
    type: "onsite",
    photo: "/placeholder.svg?height=100&width=100",
    notes: "Regular office day",
    created_at: "2024-01-15T08:45:00Z",
    updated_at: "2024-01-15T17:15:00Z",
    employee: {
      id: "2",
      user_id: "2",
      full_name: "Jane Smith",
      nik: "EMP002",
      department: "HR",
      position: "HR Manager",
      phone: "+1234567891",
      address: "456 Oak Ave",
      hire_date: "2023-02-01T00:00:00Z",
      status: "active",
      created_at: "2023-02-01T00:00:00Z",
      updated_at: "2023-02-01T00:00:00Z",
    },
  },
]

const mockEmployees: Employee[] = [
  {
    id: "1",
    user_id: "1",
    full_name: "John Doe",
    nik: "EMP001",
    department: "Engineering",
    position: "Frontend Developer",
    phone: "+1234567890",
    address: "123 Main St",
    hire_date: "2023-01-15T00:00:00Z",
    status: "active",
    created_at: "2023-01-15T00:00:00Z",
    updated_at: "2023-01-15T00:00:00Z",
  },
  {
    id: "2",
    user_id: "2",
    full_name: "Jane Smith",
    nik: "EMP002",
    department: "HR",
    position: "HR Manager",
    phone: "+1234567891",
    address: "456 Oak Ave",
    hire_date: "2023-02-01T00:00:00Z",
    status: "active",
    created_at: "2023-02-01T00:00:00Z",
    updated_at: "2023-02-01T00:00:00Z",
  },
]

interface AttendanceMonitoringProps {
  onViewPhoto: (photo: string) => void
}

export default function AttendanceMonitoring({ onViewPhoto }: AttendanceMonitoringProps) {
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(mockAttendance)
  const [showFilters, setShowFilters] = useState(false)
  const [filters, setFilters] = useState<AttendanceFilter>({
    employee_id: "",
    date_from: "",
    date_to: "",
    type: "",
    department: "",
  })

  const departments = [...new Set(mockEmployees.map((emp) => emp.department))]

  const filteredAttendance = attendance.filter((record) => {
    if (filters.employee_id && record.employee_id !== filters.employee_id) return false
    if (filters.date_from && record.date < filters.date_from) return false
    if (filters.date_to && record.date > filters.date_to) return false
    if (filters.type && record.type !== filters.type) return false
    if (filters.department && record.employee?.department !== filters.department) return false
    return true
  })

  const calculateWorkingHours = (checkIn: string, checkOut?: string) => {
    if (!checkOut) return 0
    const start = new Date(checkIn)
    const end = new Date(checkOut)
    return Math.round(((end.getTime() - start.getTime()) / (1000 * 60 * 60)) * 10) / 10
  }

  const exportToCSV = () => {
    const headers = ["Employee", "NIK", "Date", "Check In", "Check Out", "Type", "Working Hours", "Department"]
    const csvData = filteredAttendance.map((record) => [
      record.employee?.full_name || "",
      record.employee?.nik || "",
      record.date,
      new Date(record.check_in).toLocaleTimeString(),
      record.check_out ? new Date(record.check_out).toLocaleTimeString() : "",
      record.type,
      calculateWorkingHours(record.check_in, record.check_out),
      record.employee?.department || "",
    ])

    const csvContent = [headers, ...csvData].map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `attendance_report_${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Attendance Monitoring</h2>
          <p className="text-gray-600">Monitor and track employee attendance records</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button variant="outline" onClick={exportToCSV}>
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <Card>
          <CardHeader>
            <CardTitle>Filter Attendance Records</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <div>
                <Label htmlFor="employee_id">Employee</Label>
                <select
                  id="employee_id"
                  value={filters.employee_id}
                  onChange={(e) => setFilters((prev) => ({ ...prev, employee_id: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  <option value="">All Employees</option>
                  {mockEmployees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.full_name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <Label htmlFor="date_from">From Date</Label>
                <Input
                  id="date_from"
                  type="date"
                  value={filters.date_from}
                  onChange={(e) => setFilters((prev) => ({ ...prev, date_from: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="date_to">To Date</Label>
                <Input
                  id="date_to"
                  type="date"
                  value={filters.date_to}
                  onChange={(e) => setFilters((prev) => ({ ...prev, date_to: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="type">Work Type</Label>
                <select
                  id="type"
                  value={filters.type}
                  onChange={(e) => setFilters((prev) => ({ ...prev, type: e.target.value as "onsite" | "wfh" | "" }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  <option value="">All Types</option>
                  <option value="wfh">Work From Home</option>
                  <option value="onsite">On Site</option>
                </select>
              </div>

              <div>
                <Label htmlFor="department">Department</Label>
                <select
                  id="department"
                  value={filters.department}
                  onChange={(e) => setFilters((prev) => ({ ...prev, department: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                >
                  <option value="">All Departments</option>
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>
                      {dept}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex space-x-2 mt-4">
              <Button
                variant="outline"
                onClick={() => setFilters({ employee_id: "", date_from: "", date_to: "", type: "", department: "" })}
              >
                Clear Filters
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{filteredAttendance.length}</div>
            <p className="text-sm text-gray-600">Total Records</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-green-600">
              {filteredAttendance.filter((r) => r.type === "wfh").length}
            </div>
            <p className="text-sm text-gray-600">WFH Records</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-blue-600">
              {filteredAttendance.filter((r) => r.type === "onsite").length}
            </div>
            <p className="text-sm text-gray-600">Onsite Records</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-purple-600">
              {Math.round(
                (filteredAttendance.reduce((acc, r) => acc + calculateWorkingHours(r.check_in, r.check_out), 0) /
                  filteredAttendance.length) *
                  10,
              ) / 10 || 0}
              h
            </div>
            <p className="text-sm text-gray-600">Avg. Working Hours</p>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-left p-4 font-medium">Employee</th>
                  <th className="text-left p-4 font-medium">Date</th>
                  <th className="text-left p-4 font-medium">Check In</th>
                  <th className="text-left p-4 font-medium">Check Out</th>
                  <th className="text-left p-4 font-medium">Type</th>
                  <th className="text-left p-4 font-medium">Working Hours</th>
                  <th className="text-left p-4 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAttendance.map((record) => (
                  <tr key={record.id} className="border-b hover:bg-gray-50">
                    <td className="p-4">
                      <div>
                        <p className="font-medium">{record.employee?.full_name}</p>
                        <p className="text-sm text-gray-600">
                          {record.employee?.nik} • {record.employee?.department}
                        </p>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                        {new Date(record.date).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2 text-green-500" />
                        {new Date(record.check_in).toLocaleTimeString()}
                      </div>
                    </td>
                    <td className="p-4">
                      {record.check_out ? (
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-red-500" />
                          {new Date(record.check_out).toLocaleTimeString()}
                        </div>
                      ) : (
                        <span className="text-gray-400">Not yet</span>
                      )}
                    </td>
                    <td className="p-4">
                      <Badge variant={record.type === "wfh" ? "default" : "secondary"}>
                        <MapPin className="h-3 w-3 mr-1" />
                        {record.type === "wfh" ? "Work From Home" : "On Site"}
                      </Badge>
                    </td>
                    <td className="p-4">
                      <span className="font-mono">{calculateWorkingHours(record.check_in, record.check_out)}h</span>
                    </td>
                    <td className="p-4">
                      <Button size="sm" variant="outline" onClick={() => onViewPhoto(record.photo)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
