"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/contexts/AuthContext"
import { Camera, Clock, MapPin, LogOut, Calendar, CheckCircle, Building2, User } from "lucide-react"
import type { AttendanceRecord } from "@/types"

export default function EmployeeDashboard() {
  const { user, logout } = useAuth()
  const [isCheckedIn, setIsCheckedIn] = useState(false)
  const [photo, setPhoto] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null)
  const [activeTab, setActiveTab] = useState<"attendance" | "profile">("attendance")

  const handlePhotoCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        setPhoto(e.target?.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleCheckIn = async () => {
    if (!photo) {
      alert("Please upload a photo first")
      return
    }

    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const newAttendance: AttendanceRecord = {
      id: Date.now().toString(),
      employeeId: user!.id,
      employeeName: user!.name,
      date: new Date().toISOString().split("T")[0],
      checkInTime: new Date().toLocaleTimeString(),
      photo: photo,
      location: "Work From Home",
      status: "present",
    }

    setTodayAttendance(newAttendance)
    setIsCheckedIn(true)
    setIsLoading(false)
  }

  const handleCheckOut = async () => {
    setIsLoading(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    if (todayAttendance) {
      const updatedAttendance = {
        ...todayAttendance,
        checkOutTime: new Date().toLocaleTimeString(),
        workingHours: 8, // Calculate actual working hours
      }
      setTodayAttendance(updatedAttendance)
    }

    setIsLoading(false)
  }

  const currentTime = new Date().toLocaleTimeString()
  const currentDate = new Date().toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Building2 className="h-8 w-8 text-blue-600 mr-3" />
              <h1 className="text-xl font-semibold">WFH Attendance</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user?.name}</span>
              <Button variant="outline" size="sm" onClick={logout}>
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-6 space-y-6">
        {/* Navigation Tabs */}
        <div className="flex space-x-1">
          <Button
            variant={activeTab === "attendance" ? "default" : "outline"}
            onClick={() => setActiveTab("attendance")}
          >
            <Clock className="h-4 w-4 mr-2" />
            Attendance
          </Button>
          <Button variant={activeTab === "profile" ? "default" : "outline"} onClick={() => setActiveTab("profile")}>
            <User className="h-4 w-4 mr-2" />
            Profile & History
          </Button>
        </div>

        {/* Attendance Tab */}
        {activeTab === "attendance" && (
          <div className="space-y-6">
            {/* Current Time Card */}
            <Card>
              <CardContent className="p-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-gray-900 mb-2">{currentTime}</div>
                  <div className="text-lg text-gray-600 flex items-center justify-center">
                    <Calendar className="h-5 w-5 mr-2" />
                    {currentDate}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Attendance Status */}
            {todayAttendance && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                    Today's Attendance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-sm text-gray-600">Check In</p>
                      <p className="font-semibold">{todayAttendance.checkInTime}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Check Out</p>
                      <p className="font-semibold">{todayAttendance.checkOutTime || "Not yet"}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Location</p>
                      <p className="font-semibold flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {todayAttendance.location}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Status</p>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        {todayAttendance.status}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Check In/Out Section */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Photo Upload */}
              <Card>
                <CardHeader>
                  <CardTitle>Upload Work Photo</CardTitle>
                  <CardDescription>Take a photo as proof of working from home</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <input
                    type="file"
                    accept="image/*"
                    capture="user"
                    onChange={handlePhotoCapture}
                    ref={fileInputRef}
                    className="hidden"
                  />

                  {photo ? (
                    <div className="space-y-4">
                      <img
                        src={photo || "/placeholder.svg"}
                        alt="Work photo"
                        className="w-full h-48 object-cover rounded-lg border"
                      />
                      <Button variant="outline" onClick={() => fileInputRef.current?.click()} className="w-full">
                        <Camera className="h-4 w-4 mr-2" />
                        Retake Photo
                      </Button>
                    </div>
                  ) : (
                    <Button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full h-32 border-2 border-dashed border-gray-300 hover:border-gray-400"
                      variant="outline"
                    >
                      <div className="text-center">
                        <Camera className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                        <span>Take Photo</span>
                      </div>
                    </Button>
                  )}
                </CardContent>
              </Card>

              {/* Attendance Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Attendance Actions</CardTitle>
                  <CardDescription>Check in/out for today's work session</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {!isCheckedIn ? (
                    <Button
                      onClick={handleCheckIn}
                      disabled={!photo || isLoading}
                      className="w-full h-16 text-lg"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Clock className="h-5 w-5 mr-2 animate-spin" />
                          Checking In...
                        </>
                      ) : (
                        <>
                          <Clock className="h-5 w-5 mr-2" />
                          Check In
                        </>
                      )}
                    </Button>
                  ) : (
                    <Button
                      onClick={handleCheckOut}
                      disabled={isLoading || todayAttendance?.checkOutTime !== undefined}
                      variant="outline"
                      className="w-full h-16 text-lg bg-transparent"
                      size="lg"
                    >
                      {isLoading ? (
                        <>
                          <Clock className="h-5 w-5 mr-2 animate-spin" />
                          Checking Out...
                        </>
                      ) : todayAttendance?.checkOutTime ? (
                        "Already Checked Out"
                      ) : (
                        <>
                          <Clock className="h-5 w-5 mr-2" />
                          Check Out
                        </>
                      )}
                    </Button>
                  )}

                  {!photo && (
                    <p className="text-sm text-gray-500 text-center">Please upload a photo before checking in</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Profile & History Tab */}
        {activeTab === "profile" && (
          <div className="space-y-6">
            {/* Employee Profile Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <User className="h-5 w-5 mr-2" />
                  My Profile
                </CardTitle>
                <CardDescription>Your personal and employment information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-start space-x-6 mb-6">
                  <div className="h-20 w-20 rounded-full bg-gray-200 flex items-center justify-center">
                    {user?.employee?.photo ? (
                      <img
                        src={user.employee.photo || "/placeholder.svg"}
                        alt={user.name}
                        className="h-20 w-20 rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-10 w-10 text-gray-500" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold">{user?.employee?.full_name || user?.name}</h3>
                    <p className="text-gray-600">{user?.employee?.position}</p>
                    <p className="text-sm text-gray-500">NIK: {user?.employee?.nik}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900">Personal Information</h4>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-600">Email</p>
                        <p className="font-medium">{user?.email}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Phone</p>
                        <p className="font-medium">{user?.employee?.phone || "Not provided"}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Address</p>
                        <p className="font-medium">{user?.employee?.address || "Not provided"}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900">Employment Information</h4>
                    <div className="space-y-3">
                      <div>
                        <p className="text-sm text-gray-600">Department</p>
                        <p className="font-medium">{user?.employee?.department}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Position</p>
                        <p className="font-medium">{user?.employee?.position}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Hire Date</p>
                        <p className="font-medium">
                          {user?.employee?.hire_date ? new Date(user.employee.hire_date).toLocaleDateString() : "N/A"}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Status</p>
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          {user?.employee?.status || "Active"}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Attendance Statistics */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold">7</div>
                  <p className="text-sm text-gray-600">Days This Month</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600">5</div>
                  <p className="text-sm text-gray-600">WFH Days</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-600">2</div>
                  <p className="text-sm text-gray-600">Onsite Days</p>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-purple-600">8.2h</div>
                  <p className="text-sm text-gray-600">Avg. Hours/Day</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Attendance History */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2" />
                  Recent Attendance History
                </CardTitle>
                <CardDescription>Your attendance records for the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {todayAttendance && (
                    <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="text-center">
                          <div className="text-sm font-medium">Today</div>
                          <div className="text-xs text-gray-500">
                            {new Date().toLocaleDateString("en-US", { weekday: "short" })}
                          </div>
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                              Present
                            </span>
                            <span className="text-sm text-gray-600">
                              {todayAttendance.workingHours ? `${todayAttendance.workingHours}h worked` : "In progress"}
                            </span>
                          </div>
                          <div className="text-sm text-gray-500 mt-1">
                            {todayAttendance.checkInTime} - {todayAttendance.checkOutTime || "Still working"}
                          </div>
                        </div>
                      </div>
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    </div>
                  )}

                  {/* Mock previous days */}
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="text-center">
                        <div className="text-sm font-medium">Yesterday</div>
                        <div className="text-xs text-gray-500">Fri</div>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            Present
                          </span>
                          <span className="text-sm text-gray-600">8.5h worked</span>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">09:00 AM - 05:30 PM</div>
                      </div>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="text-center">
                        <div className="text-sm font-medium">Jan 12</div>
                        <div className="text-xs text-gray-500">Thu</div>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                            Onsite
                          </span>
                          <span className="text-sm text-gray-600">8.0h worked</span>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">08:30 AM - 04:30 PM</div>
                      </div>
                    </div>
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>

                  <div className="flex items-center justify-between p-3 border rounded-lg bg-red-50">
                    <div className="flex items-center space-x-3">
                      <div className="text-center">
                        <div className="text-sm font-medium">Jan 11</div>
                        <div className="text-xs text-gray-500">Wed</div>
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            Absent
                          </span>
                          <span className="text-sm text-gray-600">Sick leave</span>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">Medical appointment</div>
                      </div>
                    </div>
                    <div className="h-5 w-5 rounded-full bg-red-200"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  )
}
